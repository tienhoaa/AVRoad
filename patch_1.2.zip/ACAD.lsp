;; ========================================================
;; AVRoad 2026 Solution - Startup Configuration
;; ========================================================
(defun S::STARTUP()
  (setvar "CMDECHO" 0)
  (setvar "NOMUTT" 1)
  (vl-catch-all-apply '(lambda ()
    ;; Smooth drafting and high-performance settings
    (setvar "WHIPARC" 1)
    (setvar "VIEWRES" 20000)
    (setvar "VTENABLE" 3)
    (setvar "VTDURATION" 150)
    (setvar "DRAGMODE" 2)
    (setvar "ZOOMFACTOR" 60)

    ;; Load menus only if not already loaded
    (if (not (menugroup "KSVN")) (command "_.menuload" "KSVN"))
    (if (not (menugroup "VNROAD")) (command "_.menuload" "VNROAD"))
    (if (not (menugroup "SANNEN")) (command "_.menuload" "SANNEN"))
    (if (not (menugroup "KVN")) (command "_.menuload" "KVN"))
    (if (not (menugroup "DCCT")) (command "_.menuload" "DCCT"))
    (if (not (menugroup "TDT3D")) (command "_.menuload" "TDT3D"))
    (if (not (menugroup "RM")) (command "_.menuload" "RM"))

    ;; Enable hardware acceleration
    (command "-3dconfig" "_acceleration" "_on" "_exit")
  ))
  (setvar "NOMUTT" 0)
  (setvar "CMDECHO" 1)
  (princ "\nAVRoad 2026 Solution - San sang lam viec.\n")
  (princ)
)
