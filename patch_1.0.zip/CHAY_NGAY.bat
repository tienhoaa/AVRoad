@echo off
start "" "%~dp0AVRoad.exe"
