;;; ==========================================================================
;;; AVROAD 2026 SOLUTION - KHOI TAO HE THONG ON DINH 100%
;;; Giao dien goc chuan hoa, toc do toi uu, 7 Menu AV_ luon san sang
;;; ==========================================================================

(vl-load-com)

;; 1. Toi uu hoa he thong (Hieu nang cao nhat, khong loi)
(setvar "CMDECHO" 0)
(setvar "NOMUTT" 0)
(setvar "FILEDIA" 1)
(setvar "CMDDIA" 1)
(setvar "MENUBAR" 1)          ; Luon hien thi thanh Menu Bar tren cung
(setvar "STARTUP" 0)          ; Vao thang ban ve, khong mo hop thoai startup cu
(setvar "DEMANDLOAD" 3)       ; Nap ARX thong minh theo yeu cau
(setvar "INDEXCTL" 0)         ; Khong ton bo nho lap chi muc
(setvar "DRAWORDERCTL" 0)     ; Tang toc hien thi ve
(setvar "VTENABLE" 0)         ; Tat animation giat lag -> Zoom pan tuc thi sieu muot!
(setvar "ZOOMFACTOR" 80)      ; Toc do zoom chuot cuc nhay
(setvar "WHIPARC" 1)          ; Duong tron va cung tron tron tria, khong bi gay goc
(setvar "DRAGMODE" 2)         ; Keo tha doi tuong thoi gian thuc
(setvar "SELECTIONPREVIEW" 2) ; Khong bi lag khi re chuot qua ban ve nang
(setvar "HIGHLIGHT" 1)
(setvar "MAXSORT" 5000)       ; Sap xep danh sach layer sieu nhanh
(setvar "DYNMODE" 3)          ; Nhap lenh dong duoi dau chuot
(setvar "DYNPROMPT" 1)        ; Nhac lenh duoi dau chuot
(setvar "SHORTCUTMENU" 27)    ; Chuot phai thong minh (Bam nhanh = Enter, Giu = Menu)
(setvar "CURSORSIZE" 100)     ; Soi toc con tro chuot full man hinh
(setvar "GRIDMODE" 0)         ; An luoi de man hinh thoang va nhe

;; 2. Luoc bo cac thanh phan thong bao gay cham may
(vl-catch-all-apply '(lambda () (arxunload "WSCommCntrAcCon.arx")))
(vl-catch-all-apply '(lambda () (arxunload "AcadAcLaunchNFW.arx")))

;; 3. Nap module loi thiet ke tuyen (Dam bao DLBD va cac lenh tuyen luon san sang)
(if (not (member "tdtobjects17.dbx" (mapcar 'strcase (arx))))
  (vl-catch-all-apply '(lambda () (arxload "TDTObjects17.dbx")))
)
(if (not (member "alignmentdb17.dbx" (mapcar 'strcase (arx))))
  (vl-catch-all-apply '(lambda () (arxload "AlignmentDb17.dbx")))
)
(if (not (member "nhapsolieutuyen17.arx" (mapcar 'strcase (arx))))
  (vl-catch-all-apply '(lambda () (arxload "NhapSoLieuTuyen17.arx")))
)

;; 4. Khoi tao Express Tools
(if (findfile "acetauto.lsp")
  (vl-catch-all-apply '(lambda () (load "acetauto.lsp")))
)

;; 5. Tu dong kiem tra va nap 7 Menu chuyen nganh AV_ len MenuBar theo thu tu chuan:
;; File -> Window, Express Tools, AV_KS, AV_Road, AV_SanNen, AV_Kenh, AV_DiaChat, AV_3D, AV_VachSon, Help
(defun LoadEngineeringMenus ()
  (setvar "CMDECHO" 0)
  
  ;; Dam bao tung nhom CUI da duoc menuload neu chua co
  (if (not (menucmd "GEXPRESS.ID_Express=?"))
    (if (findfile "acetmain.cui") (vl-catch-all-apply '(lambda () (command "_.menuload" "acetmain"))))
  )
  (if (not (menucmd "GKSVN.POP1=?"))
    (if (findfile "KSVN.cui") (vl-catch-all-apply '(lambda () (command "_.menuload" "KSVN"))))
  )
  (if (not (menucmd "GVNROAD.POP1=?"))
    (if (findfile "VNROAD.cui") (vl-catch-all-apply '(lambda () (command "_.menuload" "VNROAD"))))
  )
  (if (not (menucmd "GSANNEN.POP1=?"))
    (if (findfile "SANNEN.cui") (vl-catch-all-apply '(lambda () (command "_.menuload" "SANNEN"))))
  )
  (if (not (menucmd "GKVN.POP1=?"))
    (if (findfile "KVN.cui") (vl-catch-all-apply '(lambda () (command "_.menuload" "KVN"))))
  )
  (if (not (menucmd "GDCCT.POP1=?"))
    (if (findfile "DCCT.cui") (vl-catch-all-apply '(lambda () (command "_.menuload" "DCCT"))))
  )
  (if (not (menucmd "GTDT3D.POP1=?"))
    (if (findfile "TDT3D.cui") (vl-catch-all-apply '(lambda () (command "_.menuload" "TDT3D"))))
  )
  (if (not (menucmd "GRM.POP1=?"))
    (if (findfile "RM.cui") (vl-catch-all-apply '(lambda () (command "_.menuload" "RM"))))
  )

  ;; Dinh vi cac Menu vao dung vi tri tren MenuBar
  (vl-catch-all-apply '(lambda () (menucmd "P11=+EXPRESS.pop1")))
  (vl-catch-all-apply '(lambda () (menucmd "P12=+KSVN.POP1")))
  (vl-catch-all-apply '(lambda () (menucmd "P13=+VNROAD.POP1")))
  (vl-catch-all-apply '(lambda () (menucmd "P14=+SANNEN.POP1")))
  (vl-catch-all-apply '(lambda () (menucmd "P15=+KVN.POP1")))
  (vl-catch-all-apply '(lambda () (menucmd "P16=+DCCT.POP1")))
  (vl-catch-all-apply '(lambda () (menucmd "P17=+TDT3D.POP1")))
  (vl-catch-all-apply '(lambda () (menucmd "P18=+RM.POP1")))
  (vl-catch-all-apply '(lambda () (menucmd "P19=+ACAD.pop11")))
)

;; 6. Tien ich phim tat cao cap
;; SS: Chon nhanh cac doi tuong giong nhau (SelectSimilar)
(defun c:SELECTSIMILAR (/ ss ent entData objType layName filterList total resSS)
  (prompt "\n[SELECTSIMILAR]: Chon doi tuong mau: ")
  (setq ss (ssget ":S"))
  (if (null ss) (setq ss (ssget "_I")))
  (if ss
    (progn
      (setq ent (ssname ss 0))
      (setq entData (entget ent))
      (setq objType (cdr (assoc 0 entData)))
      (setq layName (cdr (assoc 8 entData)))
      (setq filterList (list (cons 0 objType) (cons 8 layName)))
      (setq resSS (ssget "_X" filterList))
      (if resSS
        (progn
          (setq total (sslength resSS))
          (sssetfirst nil resSS)
          (prompt (strcat "\n[OK] Da chon " (itoa total) " doi tuong <" objType "> tren Layer <" layName ">!"))
        )
        (prompt "\nKhong tim thay doi tuong nao khac.")
      )
    )
    (prompt "\nChua chon doi tuong nao.")
  )
  (princ)
)
(defun c:SS () (c:SELECTSIMILAR))

;; IS: Co lap Layer (Layiso)
(defun c:IS (/ ss)
  (prompt "\n[ISOLATE]: Chon doi tuong muon giu lai tren man hinh: ")
  (setq ss (ssget))
  (if ss (command "_.layiso" ss ""))
  (princ)
)

;; UNIS: Hien lai toan bo Layer (Layuniso)
(defun c:UNIS ()
  (command "_.layuniso")
  (prompt "\n[OK] Da hien lai toan bo layer!")
  (princ)
)

;; MAUNEN: Chuyen doi mau nen ban ve (Xam / Den / Trang)
(defun c:MAUNEN (/ acadApp pref display opt)
  (setq acadApp (vlax-get-acad-object))
  (setq pref (vla-get-Preferences acadApp))
  (setq display (vla-get-Display pref))
  (initget "1 2 3")
  (setq opt (getkword "\nChon mau nen ban ve: [1] Xam hien dai / [2] Den tuyen / [3] Trang <1>: "))
  (if (null opt) (setq opt "1"))
  (cond
    ((= opt "1")
      (vla-put-GraphicsWinModelBackgrndColor display 3156001)
      (prompt "\n[OK] Da chuyen sang Nen Xam Hien Dai!")
    )
    ((= opt "2")
      (vla-put-GraphicsWinModelBackgrndColor display 0)
      (prompt "\n[OK] Da chuyen sang Nen Den truyen thong!")
    )
    ((= opt "3")
      (vla-put-GraphicsWinModelBackgrndColor display 16777215)
      (prompt "\n[OK] Da chuyen sang Nen Trang in an!")
    )
  )
  (princ)
)

;; CHUOTPHAI: Thiet lap chuot phai (Enter / Menu)
(defun c:CHUOTPHAI (/ opt)
  (initget "1 2 3")
  (setq opt (getkword "\nChe do chuot phai: [1] Bam nhanh=Enter, Giu=Menu (Mac dinh) / [2] Luon luon Enter / [3] Luon luon Menu <1>: "))
  (if (null opt) (setq opt "1"))
  (cond
    ((= opt "1")
      (setvar "SHORTCUTMENU" 27)
      (prompt "\n[OK] Da thiet lap: Bam nhanh chuot phai = Enter, Giu chuot phai = Hien Menu!")
    )
    ((= opt "2")
      (setvar "SHORTCUTMENU" 0)
      (prompt "\n[OK] Da thiet lap: Bam chuot phai luon luon la Enter!")
    )
    ((= opt "3")
      (setvar "SHORTCUTMENU" 11)
      (prompt "\n[OK] Da thiet lap: Bam chuot phai luon luon mo Menu!")
    )
  )
  (princ)
)

;; HELP: Huong dan & Tra cuu lenh
(defun c:HELP ()
  (alert "AVROAD 2026 - HUONG DAN & TRA CUU LENH:\n\n1. Bo cong cu thiet ke tuyen & ha tang:\n- DLBD: Nhap du lieu binh do\n- TT: Thiet ke tim tuyen\n- HCT: Hieu chinh tuyen\n- TD: Thiet ke trac doc\n- TN / TKTN: Thiet ke trac ngang\n\n2. Phim tat & Tien ich nhanh:\n- SS: Chon nhanh doi tuong (SelectSimilar)\n- IS: Co lap Layer (Layiso)\n- UNIS: Hien lai toan bo Layer\n- MAUNEN: Chuyen doi mau nen ban ve (Xam BIM, Den, Trang)\n- CHUOTPHAI: Cai dat chuot phai Enter / Menu\n- AVSETTING: Mo trung tam cai dat AVRoad")
  (princ)
)

;; Mo bang cai dat
(defun c:AVSETTING (/ curDir settingExe)
  (setq curDir (vl-filename-directory (findfile "acad.exe")))
  (if (null curDir) (setq curDir (getvar "DWGPREFIX")))
  (setq settingExe (strcat curDir "\\AVSetting.exe"))
  (if (findfile settingExe)
    (startapp settingExe)
    (prompt "\n[Loi]: Khong tim thay file AVSetting.exe!")
  )
  (princ)
)
(defun c:SETTING () (c:AVSETTING))

;; 7. Khoi dong tong the khi mo ban ve
(defun S::STARTUP ()
  (setvar "CMDECHO" 0)
  
  ;; Nap va sap xep 7 Menu AV_
  (LoadEngineeringMenus)

  ;; Dong tat ca cac bang Tool Palettes va Sheet Set Manager
  (vl-catch-all-apply '(lambda () (command "_.toolpalettesclose")))
  (vl-catch-all-apply '(lambda () (command "_.sheetsetclose")))

  ;; Chuyen bieu tuong toa do OXY ve kieu 2D co dien mac dinh gon dep
  (vl-catch-all-apply '(lambda () (command "_.-ucsicon" "_p" "_2d" "" "")))
  (vl-catch-all-apply '(lambda () (command "_.ucsicon" "_or")))

  (setvar "MENUBAR" 1)
  (setvar "FILEDIA" 1)
  (setvar "CMDDIA" 1)
  (setvar "CMDECHO" 1)

  (prompt "\n==================================================================")
  (prompt "\n   AVROAD SOLUTION 2026 - ON DINH VA SAN SANG")
  (prompt "\n   * Bo cong cu thiet ke: DLBD, TT, PSC, HCT, TD, DD, TN, TKTN...")
  (prompt "\n   * 7 Menu chuyen nganh AV_ da hien thi day du tren MenuBar.")
  (prompt "\n   * Phim tat: SS (Chon nhanh), IS (Co lap layer), UNIS (Hien layer)")
  (prompt "\n   * Tien ich: MAUNEN (Doi mau nen), CHUOTPHAI, AVSETTING, HELP")
  (prompt "\n==================================================================\n")
  (princ)
)

(princ)
