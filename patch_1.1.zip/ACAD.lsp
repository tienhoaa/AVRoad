;;; ==========================================================================
;;; AVROAD 2026 SOLUTION - KHOI TAO HE THONG ON DINH 100%
;;; Giao dien goc chuan hoa, toc do toi uu, khong quang cao gay phien
;;; ==========================================================================

(vl-load-com)

;; 1. Toi uu hoa he thong (Hieu nang cao nhat, khong loi)
(setvar "CMDECHO" 0)
(setvar "NOMUTT" 0)
(setvar "FILEDIA" 1)
(setvar "CMDDIA" 1)
(setvar "STARTUP" 0)          ; Vao thang ban ve, khong mo hop thoai startup cu
(setvar "DEMANDLOAD" 3)       ; Nap ARX thong minh theo yeu cau
(setvar "INDEXCTL" 0)         ; Khong ton bo nho lap chi muc
(setvar "DRAWORDERCTL" 0)     ; Tang toc hien thi ve
(setvar "VTENABLE" 0)         ; Tat animation giat lag -> Zoom pan tuc thi sieu muot!
(setvar "ZOOMFACTOR" 80)      ; Toc do zoom chuot cuc nhay
(setvar "WHIPARC" 1)          ; Duong tron va cung tron tron tria, khong bi gay goc
(setvar "DRAGMODE" 2)         ; Keo tha doi tuong thoi gian thuc
(setvar "SELECTIONPREVIEW" 2) ; Khong bi lag khi re chuot qua ban ve nang
(setvar "HIGHLIGHT" 1)
(setvar "MAXSORT" 5000)       ; Sap xep danh sach layer sieu nhanh
(setvar "DYNMODE" 3)          ; Nhap lenh dong duoi dau chuot
(setvar "DYNPROMPT" 1)        ; Nhac lenh duoi dau chuot
(setvar "SHORTCUTMENU" 27)    ; Chuot phai thong minh (Bam nhanh = Enter, Giu = Menu)
(setvar "CURSORSIZE" 100)     ; Soi toc con tro chuot full man hinh
(setvar "GRIDMODE" 0)         ; An luoi de man hinh thoang va nhe

;; 2. Luoc bo cac thanh phan thong bao gay cham may
(vl-catch-all-apply '(lambda () (arxunload "WSCommCntrAcCon.arx")))
(vl-catch-all-apply '(lambda () (arxunload "AcadAcLaunchNFW.arx")))

;; 3. Nap module loi thiet ke tuyen (Dam bao DLBD va cac lenh tuyen luon san sang)
(if (not (member "tdtobjects17.dbx" (mapcar 'strcase (arx))))
  (vl-catch-all-apply '(lambda () (arxload "TDTObjects17.dbx")))
)
(if (not (member "alignmentdb17.dbx" (mapcar 'strcase (arx))))
  (vl-catch-all-apply '(lambda () (arxload "AlignmentDb17.dbx")))
)
(if (not (member "nhapsolieutuyen17.arx" (mapcar 'strcase (arx))))
  (vl-catch-all-apply '(lambda () (arxload "NhapSoLieuTuyen17.arx")))
)

;; 4. Khoi tao Express Tools
(if (findfile "acetauto.lsp")
  (vl-catch-all-apply '(lambda () (load "acetauto.lsp")))
)

;; 5. Sap xep MenuBar theo trat tu chuan:
;; File -> Window, Express Tools, 7 Menu chuyen nganh TDT, Help
(defun LoadEngineeringMenus ()
  (setvar "CMDECHO" 0)
  (vl-catch-all-apply '(lambda () (menucmd "P11=+EXPRESS.pop1")))
  (vl-catch-all-apply '(lambda () (menucmd "P12=+KSVN.pop1")))
  (vl-catch-all-apply '(lambda () (menucmd "P13=+VNROAD.pop1")))
  (vl-catch-all-apply '(lambda () (menucmd "P14=+SANNEN.pop1")))
  (vl-catch-all-apply '(lambda () (menucmd "P15=+KVN.pop1")))
  (vl-catch-all-apply '(lambda () (menucmd "P16=+DCCT.pop1")))
  (vl-catch-all-apply '(lambda () (menucmd "P17=+TDT3D.pop1")))
  (vl-catch-all-apply '(lambda () (menucmd "P18=+RM.pop1")))
  (vl-catch-all-apply '(lambda () (menucmd "P19=+ACAD.pop11")))
)

;; 6. Tien ich phim tat cao cap
;; SS: Chon nhanh cac doi tuong giong nhau (SelectSimilar)
(defun c:SELECTSIMILAR (/ ss ent entData objType layName filterList total resSS)
  (prompt "\n[SELECTSIMILAR]: Chon doi tuong mau: ")
  (setq ss (ssget ":S"))
  (if (null ss) (setq ss (ssget "_I")))
  (if ss
    (progn
      (setq ent (ssname ss 0))
      (setq entData (entget ent))
      (setq objType (cdr (assoc 0 entData)))
      (setq layName (cdr (assoc 8 entData)))
      (setq filterList (list (cons 0 objType) (cons 8 layName)))
      (setq resSS (ssget "_X" filterList))
      (if resSS
        (progn
          (setq total (sslength resSS))
          (sssetfirst nil resSS)
          (prompt (strcat "\n[OK] Da chon " (itoa total) " doi tuong <" objType "> tren Layer <" layName ">!"))
        )
        (prompt "\nKhong tim thay doi tuong nao khac.")
      )
    )
    (prompt "\nChua chon doi tuong nao.")
  )
  (princ)
)
(defun c:SS () (c:SELECTSIMILAR))

;; IS: Co lap Layer (Layiso)
(defun c:IS (/ ss)
  (prompt "\n[ISOLATE]: Chon doi tuong muon giu lai tren man hinh: ")
  (setq ss (ssget))
  (if ss (command "_.layiso" ss ""))
  (princ)
)

;; UNIS: Hien lai toan bo Layer (Layuniso)
(defun c:UNIS ()
  (command "_.layuniso")
  (prompt "\n[OK] Da hien lai toan bo layer!")
  (princ)
)

;; MAUNEN: Chuyen doi mau nen ban ve (Xam / Den / Trang)
(defun c:MAUNEN (/ acadApp pref display opt)
  (setq acadApp (vlax-get-acad-object))
  (setq pref (vla-get-Preferences acadApp))
  (setq display (vla-get-Display pref))
  (initget "1 2 3")
  (setq opt (getkword "\nChon mau nen ban ve: [1] Xam hien dai / [2] Den tuyen / [3] Trang <1>: "))
  (if (null opt) (setq opt "1"))
  (cond
    ((= opt "1")
      (vla-put-GraphicsWinModelBackgrndColor display 3156001)
      (prompt "\n[OK] Da chuyen sang Nen Xam Hien Dai!")
    )
    ((= opt "2")
      (vla-put-GraphicsWinModelBackgrndColor display 0)
      (prompt "\n[OK] Da chuyen sang Nen Den truyen thong!")
    )
    ((= opt "3")
      (vla-put-GraphicsWinModelBackgrndColor display 16777215)
      (prompt "\n[OK] Da chuyen sang Nen Trang in an!")
    )
  )
  (princ)
)

;; CHUOTPHAI: Thiet lap chuot phai (Enter / Menu)
(defun c:CHUOTPHAI (/ opt)
  (initget "1 2 3")
  (setq opt (getkword "\nChe do chuot phai: [1] Bam nhanh=Enter, Giu=Menu (Mac dinh) / [2] Luon luon Enter / [3] Luon luon Menu <1>: "))
  (if (null opt) (setq opt "1"))
  (cond
    ((= opt "1")
      (setvar "SHORTCUTMENU" 27)
      (prompt "\n[OK] Da thiet lap: Bam nhanh chuot phai = Enter, Giu chuot phai = Hien Menu!")
    )
    ((= opt "2")
      (setvar "SHORTCUTMENU" 0)
      (prompt "\n[OK] Da thiet lap: Bam chuot phai luon luon la Enter!")
    )
    ((= opt "3")
      (setvar "SHORTCUTMENU" 11)
      (prompt "\n[OK] Da thiet lap: Bam chuot phai luon luon mo Menu!")
    )
  )
  (princ)
)

;; Mo bang cai dat
(defun c:AVSETTING (/ curDir settingExe)
  (setq curDir (vl-filename-directory (findfile "acad.exe")))
  (if (null curDir) (setq curDir (getvar "DWGPREFIX")))
  (setq settingExe (strcat curDir "\\AVSetting.exe"))
  (if (findfile settingExe)
    (startapp settingExe)
    (prompt "\n[Loi]: Khong tim thay file AVSetting.exe!")
  )
  (princ)
)
(defun c:SETTING () (c:AVSETTING))

;; 7. Khoi dong tong the khi mo ban ve
(defun S::STARTUP ()
  (setvar "CMDECHO" 0)
  
  ;; Sap xep Menu
  (LoadEngineeringMenus)

  ;; Dong tat ca cac bang Tool Palettes va Sheet Set Manager gay phien
  (vl-catch-all-apply '(lambda () (command "_.toolpalettesclose")))
  (vl-catch-all-apply '(lambda () (command "_.sheetsetclose")))

  ;; Chuyen bieu tuong toa do OXY ve kieu 2D co dien mac dinh gon dep
  (vl-catch-all-apply '(lambda () (command "_.-ucsicon" "_p" "_2d" "" "")))
  (vl-catch-all-apply '(lambda () (command "_.ucsicon" "_or")))

  (setvar "FILEDIA" 1)
  (setvar "CMDDIA" 1)
  (setvar "CMDECHO" 1)

  (prompt "\n==================================================================")
  (prompt "\n   AVROAD SOLUTION 2026 - ON DINH VA SAN SANG")
  (prompt "\n   * Bo cong cu thiet ke: DLBD, TT, PSC, HCT, TD, DD, TN, TKTN...")
  (prompt "\n   * Menu Express & 7 Menu chuyen nganh san sang tren MenuBar.")
  (prompt "\n   * Phim tat: SS (Chon nhanh), IS (Co lap layer), UNIS (Hien layer)")
  (prompt "\n   * Tien ich: MAUNEN (Doi mau nen), CHUOTPHAI, AVSETTING")
  (prompt "\n==================================================================\n")
  (princ)
)

(princ)
