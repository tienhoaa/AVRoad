;;; ==========================================================================
;;; AVROAD SOLUTION 2026 - POWERED BY AVCAD GRAPHICS ENGINE
;;; He Thong Thiet Ke Tuyen & Ha Tang Giao Thong Chuyen Nghiep
;;; He Sinh Thai: AV BIM - COMMON DATA ENVIRONMENT (CDE)
;;; Slogan: CHUAN HOA DU LIEU CDE - TOI UU THIET KE HA TANG BIM
;;; (KHOI DONG SIEU TOC - KHONG TRE - DAY DU MENU EXPRESS & AVROAD)
;;; ==========================================================================

(vl-load-com)

;; 1. TOI UU HOA HE THONG CHO CAD KHOI DONG VA CHAY MUOT MA NHAT (MAXIMUM PERFORMANCE)
(setvar "CMDECHO" 0)
(setvar "NOMUTT" 0)
(setvar "FILEDIA" 1)
(setvar "CMDDIA" 1)
(setvar "STARTUP" 0)          ; Khong hien hop thoai Startup cu -> Vao thang ban ve
(setvar "DEMANDLOAD" 3)       ; Nap ARX thong minh theo yeu cau
(setvar "INDEXCTL" 0)         ; Khong ton bo nho lap chi muc thua
(setvar "PALETTEOPAQUE" 1)    ; Khong lam trong suot palette gay lag GPU
(setvar "DRAWORDERCTL" 0)     ; Tang toc hien thi ve
(setvar "VTENABLE" 0)         ; Tat hieu ung zoom/pan animation cham chap -> Zoom pan tuc thi, sieu muot!
(setvar "ZOOMFACTOR" 80)      ; Toc do zoom chuot cuc nhay
(setvar "WHIPARC" 1)          ; Tang toc do hoa cho duong tron, cung tron khong bi gay
(setvar "DRAGMODE" 2)         ; Keo tha doi tuong thoi gian thuc
(setvar "SELECTIONPREVIEW" 2) ; Chi preview khi goi lenh -> Re chuot qua ban ve day dac khong bi giat lag!
(setvar "HIGHLIGHT" 1)
(setvar "MAXSORT" 5000)       ; Sap xep danh sach layer sieu nhanh
(setvar "DYNMODE" 3)          ; Nhap lenh dong Dynamic Input
(setvar "DYNPROMPT" 1)        ; Nhac lenh duoi dau chuot
(setvar "SHORTCUTMENU" 27)    ; Chuot phai thong minh (Bam nhanh = Enter, Giu = Menu)
(setvar "CURSORSIZE" 100)     ; Soi toc con tro chuot full man hinh
(setvar "GRIDMODE" 0)         ; An luoi de man hinh nhe va thoang

;; 2. Luoc bo cac thanh phan thong bao thua gay cham may
(vl-catch-all-apply '(lambda () (arxunload "WSCommCntrAcCon.arx"))) ; An InfoCenter/Antenna
(vl-catch-all-apply '(lambda () (arxunload "AcadAcLaunchNFW.arx")))  ; An New Features Workshop

;; 3. Khoi tao Express Tools (sieu toc, khong gay tre)
(if (findfile "acetauto.lsp")
  (vl-catch-all-apply '(lambda () (load "acetauto.lsp")))
)

;; 4. Hien thi Express Tools va 7 Menu chuyen nganh AV tren MenuBar theo trat tu chuan
;; P1..P10: File -> Window
;; P11: Express Tools
;; P12: AV_KS (Khao sat)
;; P13: AV_Road (Thiet ke tuyen)
;; P14: AV_SanNen (San nen)
;; P15: AV_Kenh (Kenh thuy loi)
;; P16: AV_DiaChat (Dia chat cong trinh)
;; P17: AV_3D (3D Tuyen)
;; P18: AV_VachSon (Vach son & Bien bao)
;; P19: Help (Tro giup)
(defun LoadAVRoadMenus ()
  (setvar "CMDECHO" 0)
  (vl-catch-all-apply '(lambda () (menucmd "P11=+EXPRESS.pop1")))
  (vl-catch-all-apply '(lambda () (menucmd "P12=+KSVN.pop1")))
  (vl-catch-all-apply '(lambda () (menucmd "P13=+VNROAD.pop1")))
  (vl-catch-all-apply '(lambda () (menucmd "P14=+SANNEN.pop1")))
  (vl-catch-all-apply '(lambda () (menucmd "P15=+KVN.pop1")))
  (vl-catch-all-apply '(lambda () (menucmd "P16=+DCCT.pop1")))
  (vl-catch-all-apply '(lambda () (menucmd "P17=+TDT3D.pop1")))
  (vl-catch-all-apply '(lambda () (menucmd "P18=+RM.pop1")))
  (vl-catch-all-apply '(lambda () (menucmd "P19=+ACAD.pop11")))
)

;; 5. Mo trang chu AVRoad / GitHub
(defun c:WEBPAGE ()
  (startapp "explorer" "https://github.com/tienhoaa/AVRoad")
  (princ "\n[OK] Dang mo trang chu AVRoad 2026 tren trinh duyet...")
  (princ)
)
(defun c:HOMEPAGE () (c:WEBPAGE))
(defun c:AVROADPAGE () (c:WEBPAGE))

;; 6. Lenh About / Gioi thieu AVRoad 2026 (co Logo & Link)
(defun c:ABOUT (/ curDir aboutExe)
  (setq curDir (vl-filename-directory (findfile "acad.exe")))
  (if (null curDir) (setq curDir (getvar "DWGPREFIX")))
  (setq aboutExe (strcat curDir "\\AVRoad.exe"))
  (if (findfile aboutExe)
    (startapp aboutExe "/about")
    (alert "AVRoad Solution 2026\nHe Thong Thiet Ke Tuyen & Ha Tang Giao Thong Chuyen Nghiep\n\nCHUAN HOA DU LIEU CDE - TOI UU THIET KE HA TANG BIM\n\nTrang chu: https://github.com/tienhoaa/AVRoad\nBan quyen: AV Technology - All rights reserved.")
  )
  (princ)
)
(defun c:AVROAD () (c:ABOUT))
(defun c:ABOUTTDT () (c:ABOUT))
(defun c:CDE () (c:ABOUT))
(defun c:BIM () (c:ABOUT))

;; 7. Lenh Tro giup (HELP)
(defun c:HELP ()
  (alert "AVROAD SOLUTION 2026 - HUONG DAN & TRO GIUP:\n\n1. Bo cong cu thiet ke giao thong:\n- DLBD: Nhap du lieu binh do\n- TT: Thiet ke tim tuyen\n- HCT: Hieu chinh tuyen\n- TD: Thiet ke trac doc\n- TN / TKTN: Thiet ke trac ngang\n\n2. Phim tat & Tien ich nhanh:\n- SS: Chon nhanh doi tuong (SelectSimilar)\n- IS: Co lap Layer (Layiso)\n- UNIS: Hien lai toan bo Layer\n- MAUNEN: Doi mau nen (Xam BIM, Den, Trang)\n- CHUOTPHAI: Thiet lap chuot phai Enter / Menu\n- AVSETTING: Mo trung tam cai dat AVRoad\n- WEBPAGE: Mo trang chu GitHub cap nhat ban va\n\n3. Ho tro truc tuyen:\n- Website: https://github.com/tienhoaa/AVRoad")
  (princ)
)
(defun c:TDTHELP () (c:HELP))

;; 8. Lenh SELECTSIMILAR (SS) & An hien layer (IS / UNIS)
(defun c:SELECTSIMILAR (/ ss ent entData objType layName filterList total resSS)
  (prompt "\n[SELECTSIMILAR]: Chon doi tuong mau: ")
  (setq ss (ssget ":S"))
  (if (null ss) (setq ss (ssget "_I")))
  (if ss
    (progn
      (setq ent (ssname ss 0))
      (setq entData (entget ent))
      (setq objType (cdr (assoc 0 entData)))
      (setq layName (cdr (assoc 8 entData)))
      (setq filterList (list (cons 0 objType) (cons 8 layName)))
      (setq resSS (ssget "_X" filterList))
      (if resSS
        (progn
          (setq total (sslength resSS))
          (sssetfirst nil resSS)
          (prompt (strcat "\n[OK] Da chon " (itoa total) " doi tuong <" objType "> tren Layer <" layName ">!"))
        )
        (prompt "\nKhong tim thay doi tuong nao khac.")
      )
    )
    (prompt "\nChua chon doi tuong nao.")
  )
  (princ)
)
(defun c:SS () (c:SELECTSIMILAR))

(defun c:IS (/ ss)
  (prompt "\n[ISOLATE]: Chon doi tuong muon giu lai tren man hinh: ")
  (setq ss (ssget))
  (if ss (command "_.layiso" ss ""))
  (princ)
)
(defun c:UNIS ()
  (command "_.layuniso")
  (prompt "\n[OK] Da hien lai toan bo layer!")
  (princ)
)

;; 9. Lenh chuyen doi mau nen ban ve (MAUNEN: Xam BIM / Den / Trang)
(defun c:MAUNEN (/ acadApp pref display opt)
  (setq acadApp (vlax-get-acad-object))
  (setq pref (vla-get-Preferences acadApp))
  (setq display (vla-get-Display pref))
  (initget "1 2 3")
  (setq opt (getkword "\nChon mau nen ban ve: [1] Xam hien dai (BIM Dark Gray) / [2] Den tuyen / [3] Trang <1>: "))
  (if (null opt) (setq opt "1"))
  (cond
    ((= opt "1")
      (vla-put-GraphicsWinModelBackgrndColor display 3156001)
      (prompt "\n[OK] Da chuyen sang Nen Xam Hien Dai (BIM Dark Gray)!")
    )
    ((= opt "2")
      (vla-put-GraphicsWinModelBackgrndColor display 0)
      (prompt "\n[OK] Da chuyen sang Nen Den truyen thong!")
    )
    ((= opt "3")
      (vla-put-GraphicsWinModelBackgrndColor display 16777215)
      (prompt "\n[OK] Da chuyen sang Nen Trang in an!")
    )
  )
  (princ)
)

;; 10. Lenh thiet lap chuot phai (CHUOTPHAI)
(defun c:CHUOTPHAI (/ opt)
  (initget "1 2 3")
  (setq opt (getkword "\nChe do chuot phai: [1] Bam nhanh=Enter, Giu=Menu (Mac dinh) / [2] Luon luon Enter / [3] Luon luon Menu <1>: "))
  (if (null opt) (setq opt "1"))
  (cond
    ((= opt "1")
      (setvar "SHORTCUTMENU" 27)
      (prompt "\n[OK] Da thiet lap: Bam nhanh chuot phai = Enter, Giu chuot phai = Hien Menu!")
    )
    ((= opt "2")
      (setvar "SHORTCUTMENU" 0)
      (prompt "\n[OK] Da thiet lap: Bam chuot phai luon luon la Enter!")
    )
    ((= opt "3")
      (setvar "SHORTCUTMENU" 11)
      (prompt "\n[OK] Da thiet lap: Bam chuot phai luon luon mo Menu!")
    )
  )
  (princ)
)

;; 11. Lenh xuat va nap Profile ca nhan (.ARG)
(defun c:SAVEPROFILE (/ curDir acadApp prefObj profObj actProf saveFile)
  (setq curDir (vl-filename-directory (findfile "acad.exe")))
  (if (null curDir) (setq curDir (getvar "DWGPREFIX")))
  (setq acadApp (vlax-get-acad-object))
  (setq prefObj (vla-get-Preferences acadApp))
  (setq profObj (vla-get-Profiles prefObj))
  (setq actProf (vla-get-ActiveProfile profObj))
  (setq saveFile (getfiled "Luu ho so ca nhan AVRoad (.arg)" (strcat curDir "\\AVRoad_Profile.arg") "arg" 1))
  (if saveFile
    (progn
      (vla-ExportProfile profObj actProf saveFile)
      (prompt (strcat "\n[OK] Da xuat thanh cong ho so AVRoad ra file: " saveFile "\n"))
    )
  )
  (princ)
)
(defun c:XUATPROFILE () (c:SAVEPROFILE))

(defun c:LOADPROFILE (/ curDir acadApp prefObj profObj loadFile)
  (setq curDir (vl-filename-directory (findfile "acad.exe")))
  (if (null curDir) (setq curDir (getvar "DWGPREFIX")))
  (setq acadApp (vlax-get-acad-object))
  (setq prefObj (vla-get-Preferences acadApp))
  (setq profObj (vla-get-Profiles prefObj))
  (setq loadFile (getfiled "Chon file ho so ca nhan AVRoad (.arg) de nap" (strcat curDir "\\") "arg" 8))
  (if (and loadFile (vl-file-size loadFile))
    (progn
      (vla-ImportProfile profObj "AVRoad" loadFile :vlax-true)
      (vla-put-ActiveProfile profObj "AVRoad")
      (prompt (strcat "\n[OK] Da nap thanh cong ho so AVRoad: " loadFile "\n"))
    )
  )
  (princ)
)
(defun c:NAPPROFILE () (c:LOADPROFILE))

;; 12. Lenh mo AV Setting (AVSETTING / SETTING)
(defun c:AVSETTING (/ curDir settingExe)
  (setq curDir (vl-filename-directory (findfile "acad.exe")))
  (if (null curDir) (setq curDir (getvar "DWGPREFIX")))
  (setq settingExe (strcat curDir "\\AVSetting.exe"))
  (if (findfile settingExe)
    (startapp settingExe)
    (prompt "\n[Loi]: Khong tim thay file AVSetting.exe!")
  )
  (princ)
)
(defun c:SETTING () (c:AVSETTING))

;; 13. Khoi dong nhanh khi mo ban ve
(defun S::STARTUP ()
  (setvar "CMDECHO" 0)
  (vl-catch-all-apply '(lambda () (command "_.undefine" "about")))
  (LoadAVRoadMenus)
  (setvar "FILEDIA" 1)
  (setvar "CMDDIA" 1)
  (setvar "CMDECHO" 1)
  (prompt "\n==================================================================")
  (prompt "\n   AVROAD SOLUTION 2026 (POWERED BY AVCAD GRAPHICS ENGINE)")
  (prompt "\n   CHUAN HOA DU LIEU CDE - TOI UU THIET KE HA TANG BIM")
  (prompt "\n   * Bo cong cu thiet ke: DLBD, TT, PSC, HCT, TD, DD, TN, TKTN...")
  (prompt "\n   * Menu Express & 7 Menu chuyen nganh AV da san sang!")
  (prompt "\n   * Trang chu cap nhat: Go WEBPAGE de vao GitHub AVRoad")
  (prompt "\n   * Cau hinh nhanh: Go AVSETTING hoac HELP de xem tro giup")
  (prompt "\n==================================================================\n")
  (princ)
)

(princ)
