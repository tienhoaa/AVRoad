;; ========================================================
;; AVRoad 2026 Solution - Startup Configuration
;; ========================================================
(defun S::STARTUP()
  (setvar "CMDECHO" 0)
  (vl-catch-all-apply '(lambda ()
    ;; Set Command Line font to Arial
    (setenv "CmdLine.FontFace" "Arial")
    (setenv "TextWindow.FontFace" "Arial")
    (setenv "CmdLine.FontHeight" "10")
    (setenv "TextWindow.FontHeight" "10")

    ;; Smooth drafting and display optimization
    (setvar "WHIPARC" 1)
    (setvar "VIEWRES" 20000)
    (setvar "VTENABLE" 3)
    (setvar "VTDURATION" 150)
    (setvar "DRAGMODE" 2)
    (setvar "ZOOMFACTOR" 60)
  ))
  (setvar "CMDECHO" 1)
  (princ "\nAVRoad 2026 Solution - S\U+1EB5n s\U+00E0ng l\U+00E0m vi\U+1EC7c.\n")
  (princ)
)
